#!/bin/bash
# mega_auto.sh - Download from Mega.nz without quota limits
# Uses megadl (megatools) or mega.py as fallback

URL=$1
OUTPUT_DIR=${2:-/content/download}

mkdir -p "$OUTPUT_DIR"

download_with_megatools() {
    echo "[*] Attempting download via megatools..."
    megadl --path "$OUTPUT_DIR" "$URL" && return 0
    return 1
}

download_with_megapy() {
    echo "[*] Attempting download via mega.py..."
    python3 - << PYEOF
from mega import Mega
import sys

m = Mega()
m_anon = m.login()  # Anonymous login to bypass quota
try:
    m_anon.download_url("$URL", dest_path="$OUTPUT_DIR")
    print("[OK] Download complete via mega.py")
except Exception as e:
    print(f"[!] mega.py failed: {e}")
    sys.exit(1)
PYEOF
}

download_with_megacmd() {
    # Try mega-get if mega-cmd is available
    if command -v mega-get &>/dev/null; then
        echo "[*] Using mega-cmd..."
        mega-get "$URL" "$OUTPUT_DIR/" && return 0
    fi
    return 1
}

# Attempt in order of preference
download_with_megatools || download_with_megapy || download_with_megacmd || {
    echo "[!] All Mega download methods failed."
    exit 1
}

echo "[OK] Mega download finished. Files saved to: $OUTPUT_DIR"
