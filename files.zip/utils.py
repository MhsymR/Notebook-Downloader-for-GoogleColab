"""
utils.py - Utility functions for Cloud Advanced Downloader
"""

import os
import time
import subprocess
import threading
from pathlib import Path
from IPython.display import display, HTML, clear_output
import ipywidgets as widgets

DOWNLOAD_DIR = "/content/download"


# ─── Visual Helpers ───────────────────────────────────────────────────────────

def show_banner():
    html = """
    <div style="
        background: linear-gradient(135deg, #1a1a2e 0%, #16213e 50%, #0f3460 100%);
        border-radius: 12px; padding: 24px; margin: 8px 0;
        font-family: 'Segoe UI', sans-serif;
        border: 1px solid rgba(255,255,255,0.1);
        box-shadow: 0 8px 32px rgba(0,0,0,0.3);
    ">
        <div style="text-align:center;">
            <span style="font-size:2em; font-weight:700; color:#e2e8f0; letter-spacing:2px;">
                CLOUD ADVANCED DOWNLOADER
            </span><br>
            <span style="color:#64748b; font-size:0.9em; letter-spacing:4px;">
                MULTI-ENGINE  |  PARALLEL  |  HIGH SPEED
            </span>
        </div>
    </div>
    """
    display(HTML(html))


def loading_animation(message="Processing", duration=2.0, steps=20):
    """Show a smooth animated progress bar in Colab output."""
    bar_html = """
    <div id="loader-box" style="
        background: #0f172a; border-radius: 8px; padding: 16px 20px;
        margin: 8px 0; font-family: monospace; color: #94a3b8;
        border: 1px solid #1e293b;
    ">
        <div style="margin-bottom:8px;">{msg}</div>
        <div style="background:#1e293b; border-radius:4px; height:8px; overflow:hidden;">
            <div id="bar" style="
                height:100%; width:0%; border-radius:4px;
                background: linear-gradient(90deg, #3b82f6, #8b5cf6);
                transition: width 0.15s ease;
            "></div>
        </div>
    </div>
    <script>
        (function() {{
            var pct = 0;
            var bar = document.getElementById('bar');
            var timer = setInterval(function() {{
                pct += {step};
                if (pct > 100) {{ pct = 100; clearInterval(timer); }}
                bar.style.width = pct + '%';
            }}, {interval});
        }})();
    </script>
    """.format(
        msg=message,
        step=round(100 / steps, 1),
        interval=int((duration * 1000) / steps)
    )
    display(HTML(bar_html))


def status_card(title, message, status="info"):
    colors = {
        "info":    ("#1e3a5f", "#3b82f6", "#bfdbfe"),
        "success": ("#14532d", "#22c55e", "#bbf7d0"),
        "warning": ("#713f12", "#f59e0b", "#fde68a"),
        "error":   ("#7f1d1d", "#ef4444", "#fecaca"),
    }
    bg, accent, text = colors.get(status, colors["info"])
    html = f"""
    <div style="
        background:{bg}; border-left:4px solid {accent};
        border-radius:6px; padding:12px 16px; margin:6px 0;
        font-family: 'Segoe UI', sans-serif; color:{text};
    ">
        <strong>{title}</strong><br>
        <span style="font-size:0.9em; opacity:0.85;">{message}</span>
    </div>
    """
    display(HTML(html))


def progress_bar_html(pct, speed="", filename=""):
    filled = int(pct / 5)
    bar = "█" * filled + "░" * (20 - filled)
    return f"""
    <div style="
        background:#0f172a; border-radius:8px; padding:14px 18px; margin:4px 0;
        font-family: monospace; font-size:0.85em; color:#94a3b8;
        border:1px solid #1e293b;
    ">
        <div style="color:#e2e8f0; margin-bottom:6px; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;">
            {filename}
        </div>
        <div style="display:flex; align-items:center; gap:12px;">
            <span style="color:#64748b;">[</span>
            <span style="color:#3b82f6; letter-spacing:1px;">{bar}</span>
            <span style="color:#64748b;">]</span>
            <span style="color:#f0abfc; font-weight:bold;">{pct:.1f}%</span>
            {"<span style='color:#4ade80;'>" + speed + "</span>" if speed else ""}
        </div>
    </div>
    """


# ─── Engine Wrappers ──────────────────────────────────────────────────────────

def run_aria2(url: str, connections: int = 16, splits: int = 16, output_dir: str = DOWNLOAD_DIR):
    os.makedirs(output_dir, exist_ok=True)
    cmd = [
        "aria2c",
        f"--max-connection-per-server={connections}",
        f"--split={splits}",
        "--min-split-size=1M",
        "--continue=true",
        "--allow-overwrite=true",
        "--auto-file-renaming=false",
        f"--dir={output_dir}",
        url
    ]
    return subprocess.run(cmd, capture_output=True, text=True)


def run_wget(url: str, output_dir: str = DOWNLOAD_DIR):
    os.makedirs(output_dir, exist_ok=True)
    cmd = ["wget", "-c", "--show-progress", "-P", output_dir, url]
    return subprocess.run(cmd, capture_output=True, text=True)


def run_curl(url: str, output_dir: str = DOWNLOAD_DIR):
    os.makedirs(output_dir, exist_ok=True)
    filename = url.split("/")[-1].split("?")[0] or "download"
    output_path = os.path.join(output_dir, filename)
    cmd = ["curl", "-L", "-C", "-", "-o", output_path, url]
    return subprocess.run(cmd, capture_output=True, text=True)


def run_mega(url: str, output_dir: str = DOWNLOAD_DIR):
    script = os.path.join(os.path.dirname(__file__), "mega_auto.sh")
    return subprocess.run(["bash", script, url, output_dir], capture_output=True, text=True)


# ─── Download Dispatcher ──────────────────────────────────────────────────────

ENGINE_MAP = {
    "Aria2":      run_aria2,
    "Wget":       run_wget,
    "Curl":       run_curl,
    "Mega Auto":  run_mega,
}

ENGINE_INFO = {
    "Aria2": {
        "pros": "Fastest option. Multi-connection parallel downloads. Resumable.",
        "cons": "Does not work on some servers that block multi-connection."
    },
    "Wget": {
        "pros": "Universal compatibility. Recursive download support. Resumable.",
        "cons": "Single connection. Slower than Aria2."
    },
    "Curl": {
        "pros": "Excellent compatibility. Handles redirects and cookies well.",
        "cons": "Single connection. No built-in progress UI."
    },
    "Mega Auto": {
        "pros": "Auto bypass quota limits. Supports large files and resume.",
        "cons": "Only works with mega.nz links."
    },
}


def download_sequential(urls: list, engine: str, connections=16, splits=16):
    """Download URLs one by one."""
    fn = ENGINE_MAP.get(engine)
    results = []
    for i, url in enumerate(urls):
        if not url.strip():
            continue
        status_card(f"Downloading [{i+1}/{len(urls)}]", url, "info")
        if engine == "Aria2":
            result = fn(url, connections=connections, splits=splits)
        else:
            result = fn(url)
        ok = result.returncode == 0
        status = "success" if ok else "error"
        msg = "Download complete." if ok else f"Failed: {result.stderr[:200]}"
        status_card(f"File {i+1}", msg, status)
        results.append((url, ok))
    return results


def download_parallel(urls: list, engine: str, connections=16, splits=16):
    """Download all URLs simultaneously using threads."""
    threads = []
    results = {}

    def _worker(url):
        fn = ENGINE_MAP.get(engine)
        if engine == "Aria2":
            r = fn(url, connections=connections, splits=splits)
        else:
            r = fn(url)
        results[url] = r.returncode == 0

    for url in urls:
        if url.strip():
            t = threading.Thread(target=_worker, args=(url,))
            threads.append(t)
            t.start()

    status_card("Parallel Download", f"Launched {len(threads)} simultaneous download(s).", "info")
    for t in threads:
        t.join()

    for url, ok in results.items():
        status = "success" if ok else "error"
        msg = "Complete." if ok else "Failed."
        status_card(url[:60] + "...", msg, status)

    return results


def list_downloads(directory: str = DOWNLOAD_DIR):
    """Return list of files in download directory."""
    p = Path(directory)
    if not p.exists():
        return []
    return [f for f in p.iterdir() if f.is_file()]


def format_size(size_bytes: int) -> str:
    for unit in ["B", "KB", "MB", "GB"]:
        if size_bytes < 1024:
            return f"{size_bytes:.1f} {unit}"
        size_bytes /= 1024
    return f"{size_bytes:.1f} TB"
