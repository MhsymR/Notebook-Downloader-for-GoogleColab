#!/bin/bash
# installer.sh - Main installation script for Cloud Advanced Downloader

set -e

echo "[*] Updating package list..."
apt-get update -qq

echo "[*] Installing aria2..."
apt-get install -y -qq aria2

echo "[*] Installing megatools..."
apt-get install -y -qq megatools 2>/dev/null || {
    echo "[!] megatools not available via apt, installing via alternative method..."
    pip install mega.py -q
}

echo "[*] Installing wget, curl..."
apt-get install -y -qq wget curl

echo "[*] Installing Python utilities..."
pip install -q tqdm requests rich

echo "[*] Creating download directory..."
mkdir -p /content/download

echo "[OK] All installations complete."
