# Cloud Advanced Downloader

A professional, modular download manager for Google Colab. Supports multiple download engines, parallel downloads, Mega.nz bypass, and direct transfer to Google Drive — all from a clean, interactive notebook UI.

[![Open In Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/YOUR_USERNAME/Cloud-Advanced-Downloader/blob/main/notebook/Advanced_Downloader.ipynb)

---

## Features

- **4 Download Engines** — Aria2, Wget, Curl, Mega Auto
- **Multi-link input** — up to 5 URLs per session
- **Parallel or Sequential** download modes
- **Mega.nz support** — auto bypass quota limit with resume
- **Aria2 slider controls** — configure connections (1–32) and splits (1–32)
- **Realtime status cards** — per-file success/failure feedback
- **Google Drive transfer** — move files to any custom folder
- **Dark modern UI** — clean output, readable for beginners and power users

---

## Repository Structure

```
Cloud-Advanced-Downloader/
│
├── notebook/
│   └── Advanced_Downloader.ipynb   ← Main notebook (run this)
│
├── scripts/
│   ├── installer.sh                ← System package installer
│   ├── aria2_setup.sh              ← Aria2 configuration
│   ├── mega_auto.sh                ← Mega.nz download script
│   ├── transfer.sh                 ← Shell-based file transfer
│   └── utils.py                    ← Python engine wrappers & UI helpers
│
├── assets/
│   └── loading_animation.html      ← Standalone loading animation
│
├── README.md
└── requirements.txt
```

---

## How to Use

### Step 1 — Open the Notebook

Click the "Open in Colab" badge above, or upload `notebook/Advanced_Downloader.ipynb` manually to [colab.research.google.com](https://colab.research.google.com).

### Step 2 — Run Cell 1: Mount Drive (Optional)

Toggle "Mount Google Drive" to ON if you want to transfer files to Drive later. Otherwise leave it OFF — files will be saved to `/content/download`.

### Step 3 — Run Cell 2: Installation

This installs all required tools automatically:
- `aria2` — multi-connection downloader
- `megatools` or `mega.py` — Mega.nz support
- `wget`, `curl` — universal fallback engines
- Python utilities (`tqdm`, `requests`, `mega.py`)

Wait for the installation to complete before proceeding.

### Step 4 — Run Cell 3: Download

1. Select a **Download Engine** from the dropdown
2. Choose **Mode** (Sequential or Parallel)
3. Paste up to **5 URLs** in the input fields
4. Adjust **Aria2 sliders** if using Aria2 engine
5. Click **Start Download**

Files are saved to `/content/download`.

### Step 5 — Run Cell 4: Transfer to Drive

1. Enter the **folder name** in Google Drive (default: `Downloads`)
2. Click **Transfer to Drive**
3. Files are copied to `/content/drive/MyDrive/<your-folder>`

---

## Engine Reference

| Engine | Best For | Notes |
|--------|----------|-------|
| **Aria2** | Large files, maximum speed | Multi-connection. Configure connections & splits with sliders. |
| **Wget** | General downloads, recursive | Single connection. Works on almost every server. |
| **Curl** | Redirects, authenticated URLs | Handles complex URLs and cookies well. |
| **Mega Auto** | Mega.nz files | Auto bypasses quota. Requires mega.nz link. |

---

## Aria2 Settings

| Parameter | Range | Default | Effect |
|-----------|-------|---------|--------|
| Connections | 1–32 | 16 | Parallel connections per server |
| Splits | 1–32 | 16 | File chunks downloaded simultaneously |

Higher values = faster download on most servers. Some servers cap at 4–8 connections.

---

## Requirements

Python packages (automatically installed in Cell 2):

```
ipywidgets>=7.7.0
tqdm>=4.65.0
requests>=2.28.0
mega.py>=1.0.8
```

---

## Warning

- This tool is intended for downloading files you have legal rights to access.
- Bypassing Mega.nz quota uses anonymous login — do not use for private/restricted content.
- Google Colab sessions are temporary. Files in `/content/download` are lost when the session ends. Always transfer important files to Drive before closing.
- Large parallel downloads may be throttled by some servers.

---

## License

MIT License. Use freely for personal and educational purposes.
