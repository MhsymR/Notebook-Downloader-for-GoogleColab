#!/bin/bash
# aria2_setup.sh - Configure aria2 with optimal settings

CONNECTIONS=${1:-16}
SPLITS=${2:-16}

mkdir -p /root/.aria2
cat > /root/.aria2/aria2.conf << EOF
# Aria2 Configuration - Cloud Advanced Downloader
continue=true
max-connection-per-server=${CONNECTIONS}
split=${SPLITS}
min-split-size=1M
max-concurrent-downloads=5
enable-rpc=true
rpc-listen-all=false
rpc-listen-port=6800
rpc-secret=clouddownloader
file-allocation=none
disk-cache=64M
allow-overwrite=true
auto-file-renaming=false
summary-interval=1
console-log-level=warn
EOF

echo "[OK] Aria2 configured: connections=${CONNECTIONS}, splits=${SPLITS}"
