#!/bin/bash
# transfer.sh - Move files from /content/download to Google Drive

SRC=${1:-/content/download}
DEST=${2:-/content/drive/MyDrive/Downloads}

if [ ! -d "$SRC" ]; then
    echo "[!] Source directory not found: $SRC"
    exit 1
fi

if [ ! -d "/content/drive/MyDrive" ]; then
    echo "[!] Google Drive not mounted. Please mount Drive first."
    exit 1
fi

mkdir -p "$DEST"

echo "[*] Transferring files..."
echo "    From : $SRC"
echo "    To   : $DEST"
echo ""

COUNT=0
TOTAL=$(find "$SRC" -maxdepth 1 -type f | wc -l)

find "$SRC" -maxdepth 1 -type f | while read -r file; do
    FILENAME=$(basename "$file")
    COUNT=$((COUNT+1))
    echo "  [$COUNT/$TOTAL] $FILENAME"
    cp "$file" "$DEST/"
done

echo ""
echo "[OK] Transfer complete. $TOTAL file(s) moved to: $DEST"
